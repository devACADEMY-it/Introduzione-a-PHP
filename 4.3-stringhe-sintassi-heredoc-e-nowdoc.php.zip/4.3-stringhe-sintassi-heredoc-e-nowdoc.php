<!--

	Introduzione a PHP
	Stringhe: sintassi heredoc e nowdoc

	Disponibile su devACADEMY.it

-->

<!doctype html>
<html>
<head>
</head>
<body>

<?php

$numero=12;
$s=<<<"QUI"
Testo di prova....per sperimentare la nostra sintassi Heredoc
Il numero vale $numero
QUI;

$s2=<<<'QUI'
Testo di prova....per sperimentare la nostra sintassi Nowdoc
Il numero vale $numero
QUI;

?>

<p><?php echo $s; ?></p>
<p><?php echo $s2; ?></p>
</body>
</html>