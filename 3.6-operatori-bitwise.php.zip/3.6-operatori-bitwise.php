<!--

	Introduzione a PHP
	Operatori bitwise

	Disponibile su devACADEMY.it

-->

<!DOCTYPE html>
<html>
	<head></head>
	<body>
		<p><?php echo 20 << 2?></p>
		<p><?php echo 20 >> 2?></p>
		<br>
		<p><?php echo decbin(18)." <===> 18"?></p>
		<br>
		<p><?php echo decbin(20)." <===> 20"?></p>
		<p><?php echo decbin(18)." <===> 18"?></p>
		<p><?php echo decbin(20 & 18)." <===> 20 & 18"?></p>
		<br>
		<p><?php echo decbin(20)." <===> 20"?></p>
		<p><?php echo decbin(18)." <===> 18"?></p>
		<p><?php echo decbin(20 | 18)." <===> 20 | 18"?></p>
		<br>
		<p><?php echo decbin(20)." <===> 20"?></p>
		<p><?php echo decbin(18)." <===> 18"?></p>
		<p><?php echo decbin(20 ^ 18)." <===> 20 ^ 18"?></p>
	</body>
</html>