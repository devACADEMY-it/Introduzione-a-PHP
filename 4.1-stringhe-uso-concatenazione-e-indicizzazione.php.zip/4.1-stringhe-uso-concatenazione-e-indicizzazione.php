<!--

	Introduzione a PHP
	Stringhe: uso, concatenazione e indicizzazione

	Disponibile su devACADEMY.it

-->

<!doctype html>
<html>
	<head>
	</head>
	<body>
	<?php
		$mesi="gennaio <br>febbraio<br> marzo <br>";
		$altrimesi=" aprile<br> maggio<br> giugno";
	?>
		<p><?php echo $mesi{4} ?></p>
	</body>
</html>