<!--

	Introduzione a PHP
	Installare PHP su Linux

	Disponibile su devACADEMY.it

-->

<?php
	phpinfo();
?>