<!--

	Introduzione a PHP
	Conversioni tra tipi di dato

	Disponibile su devACADEMY.it

-->

<!DOCTYPE html>
<html>
	<head></head>
	<body>
		<p><?php echo TRUE*3?></p>
		<br>
		<p><?php echo "12"+5?></p>
		<p><?php echo "12hruhgei"+5?></p>
		<p><?php echo "3.56gre"+5?></p>
		<br>
		<p><?php echo  "cane"?"VERO":"FALSO" ?></p>
		<p><?php echo  ""?"VERO":"FALSO" ?></p>
		<br>
		<p><?php echo  12?"VERO":"FALSO" ?></p>
		<p><?php echo  0?"VERO":"FALSO" ?></p>
		<p><?php echo  -12.4545?"VERO":"FALSO" ?></p>
	</body>
</html>