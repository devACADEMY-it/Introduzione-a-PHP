<!--

	Introduzione a PHP
	Operatori aritmetici

	Disponibile su devACADEMY.it

-->

<?php

	$numero=12;

	echo $numero+8;   echo "<br>";

	echo $numero-5;   echo "<br>";

	echo $numero*2;   echo "<br>";

	echo $numero/6;   echo "<br>";

	echo $numero%5;   echo "<br>";

	echo -$numero;

?>