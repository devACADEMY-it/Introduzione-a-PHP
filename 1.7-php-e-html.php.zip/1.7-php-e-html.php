<!--

	Introduzione a PHP
	PHP e HTML

	Disponibile su devACADEMY.it

-->

<!DOCTYPE html>
<html>
	<head>
		<title><?php echo "Esempi in PHP (scritto in PHP)"; ?></title>
	</head>
	<body>
		<h1> <?php echo "Hello PHP! (scritto in PHP)"; ?></h1>
	</body>
</html>