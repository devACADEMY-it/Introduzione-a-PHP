<!--

	Introduzione a PHP
	Operatori di assegnazione

	Disponibile su devACADEMY.it

-->

<?php

	$numero=12;

	//$numero=$numero+8;

	$numero+=8;

	echo $numero;   echo "<br>";

	$numero-=5;

	echo $numero;   echo "<br>";

	$numero*=2;

	echo $numero;   echo "<br>";

	$numero/=6;

	echo $numero;   echo "<br>";

	$numero%=3;

	echo $numero;   echo "<br>";

	$frase="Ciao ";
	$frase.=" a tutti!";

	echo $frase;

?>