<!--

	Introduzione a PHP
	Variabili

	Disponibile su devACADEMY.it

-->

<!DOCTYPE html>
<html>
	<head>
		<title><?php echo "Esempi in PHP (scritto in PHP)" ?></title>
	</head>
	<body>
		<h1> <?php
		$messaggio="Hello PHP! (scritto in PHP)";
		echo $messaggio ?></h1>
	</body>
</html>