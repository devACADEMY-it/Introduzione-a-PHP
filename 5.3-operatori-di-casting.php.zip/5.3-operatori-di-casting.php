<!--

	Introduzione a PHP
	Operatori di casting

	Disponibile su devACADEMY.it

-->

<!DOCTYPE html>
<html>
	<head></head>
	<body>
		<p><?php echo 12.56+23 ?></p>
		<p><?php echo (int)12.56+23 ?></p>
		<p><?php echo (boolean)12.56+23 ?></p>
	</body>
</html>