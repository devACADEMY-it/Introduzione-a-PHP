<!--

	Introduzione a PHP
	Operatori logici

	Disponibile su devACADEMY.it

-->

<!doctype html>
<html>
	<head>
	</head>
	<body>
	<?php
		$vero=TRUE;
		$falso=FALSE;
		$v=8;
	?>
		<p>NEGA FALSO: "<?php echo !($v<10); ?>"</p>
		<p>Compreso tra 6 e 10: "<?php echo ($v>=6) && ($v<=10); ?>"</p>
		<p>VERO && VERO = "<?php echo $vero && $vero; ?>" </p>
		<p>VERO && FALSO = "<?php echo $vero && $falso; ?>" </p>
		<p>VERO AND FALSO = "<?php echo $vero AND $falso; ?>" </p>
		<br>
		<p>VERO || VERO = "<?php echo $vero || $vero; ?>" </p>
		<p>VERO || FALSO = "<?php echo $vero || $falso; ?>" </p>
		<p>VERO OR FALSO = "<?php echo $vero OR $falso; ?>" </p>
		<br>
		<p>VERO XOR VERO = "<?php echo $vero XOR $vero; ?>" </p>
		<p>VERO XOR FALSO = "<?php echo $vero XOR $falso; ?>" </p>
	</body>
</html>