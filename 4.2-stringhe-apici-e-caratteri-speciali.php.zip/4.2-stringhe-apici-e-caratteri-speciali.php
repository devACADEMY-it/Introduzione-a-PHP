<!--

	Introduzione a PHP
	Stringhe: apici e caratteri speciali

	Disponibile su devACADEMY.it

-->

<!doctype html>
<html>
	<head>
	</head>
	<body>
	<?php
		$add1=23;
		$add2=55;
	?>
		<p><?php echo "$add1+$add2=".($add1+$add2); ?></p>
		<p><?php echo '$add1+$add2='.($add1+$add2); ?></p>
		<p><?php echo "$add1+$add2=",($add1+$add2); ?></p>
		<p><?php print "$add1+$add2=".($add1+$add2); ?></p>
		<p><?php print '$add1+$add2='.($add1+$add2); ?></p>
		<br>
		<p><?="$add1+$add2=",($add1+$add2); ?></p>
		<p><?php echo "ci sono delle parole con \"doppi apici\""; ?></p>
		<p><?php echo 'ci sono delle parole \\ con \'apici\''; ?></p>
	</body>
</html>