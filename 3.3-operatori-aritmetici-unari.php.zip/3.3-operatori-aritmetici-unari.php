<!--

	Introduzione a PHP
	Operatori aritmetici unari

	Disponibile su devACADEMY.it

-->

<!DOCTYPE html>
<html>
	<head>
		<title>Esempi in PHP</title>
	</head>
	<body>
	<?php
		$numero=15;
	?>

		<p>
		<?php
			//++$numero; // $numero=$numero+1
			echo $numero++;
		?>
		</p>

		<p>
		<?php
			$numero--; // $numero=$numero-1
			echo $numero;
		?>
		</p>
	</body>
</html>