<!--

	Introduzione a PHP
	Stringhe: primi esempi di manipolazione

	Disponibile su devACADEMY.it

-->

<!DOCTYPE html>
<html>
	<head></head>
	<body>
	<?php
		$proverbio="A caval donato non si guarda in bocca";
		$trovare="donato";
	?>

		<p><?php echo "Lunghezza: ".strlen($proverbio); ?></p>
		<p><?php echo "Posizione: ".strpos($proverbio, $trovare); ?></p>
		<p><?php echo substr($proverbio, strpos($proverbio, $trovare), 12); ?></p>
		<p><?php echo str_replace(" ","+", $proverbio); ?></p>
		<p><?php echo str_replace("ca","__", $proverbio); ?></p>
		<br>
		<p><?php echo strcmp("ape","cane"); ?></p>
		<p><?php echo strcmp("ape","ape"); ?></p>
		<p><?php echo strcmp("gatto","cane"); ?></p>
		<br>
		<p><?php echo strcasecmp("ape","APE"); ?></p>
	</body>
</html>