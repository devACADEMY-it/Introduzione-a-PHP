<!--

	Introduzione a PHP
	Booleani e operatori di confronto

	Disponibile su devACADEMY.it

-->

<!DOCTYPE html>
<html>
	<head>
	 <title>Esempi in PHP</title>
	</head>
	<body>
		<p><?php echo "12==12 : ";   echo 12=="12"; /* TRUE - FALSE */ ?></p>
		<p><?php echo "12>30 : ";   echo 12>30; ?></p>
		<p><?php echo "12<30 : ";   echo 12<30; ?></p>
		<p><?php echo "12>=30 : ";   echo 12>=30; ?></p>
		<p><?php echo "12<=12 : ";   echo 12<=12; ?></p>
		<p><?php echo "!(12>30) : ";   echo !(12>30); ?></p>
		<p><?php echo "12!=30 : ";   echo 12!=30; ?></p>
		<p><?php echo "12===12 : ";   echo 12==="12"; ?></p>
	</body>
</html>