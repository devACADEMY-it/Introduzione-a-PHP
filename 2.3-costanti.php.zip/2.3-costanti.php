<!--

	Introduzione a PHP
	Costanti

	Disponibile su devACADEMY.it

-->

<!DOCTYPE html>
<html>
	<head>
		<title>Esempi in PHP</title>
	</head>
	<body>
	<?php
		define("PI_GRECO", 3.14);
		define("MESSAGGIO", "Benvenuto");
	?>

	<?php
		echo PI_GRECO;
	?>
		<br>
	<?php
		echo MESSAGGIO;
	?>
		<br>
	<?php
		echo __FILE__;
	?>
		<br>
	<?php
		echo __DIR__;
	?>
	</body>
</html>