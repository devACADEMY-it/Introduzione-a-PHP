<!--

	Introduzione a PHP
	Operatore ternario

	Disponibile su devACADEMY.it

-->

<!doctype html>
<html>
	<head>
	</head>
	<body>
		<?php $a=14; ?>
		<p><?php echo ($a>=5 &&$a<=10)?"compreso":"non compreso"; ?></p>
	</body>
</html>