<!--

	Introduzione a PHP
	Esempio finale

	Disponibile su devACADEMY.it

-->

<?php

  $votoJava=8;
  $votoPHP=9;
  $votoInglese=6;

  $totale=$votoJava+$votoPHP+$votoInglese;
  $media=$totale/3;

  echo "Media: ".$media." <br>";
  echo ($media>=8)?"Assunto!":"Mi dispiace, non sei assunto..."

?>