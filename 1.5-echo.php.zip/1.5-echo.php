<!--

	Introduzione a PHP
	Echo

	Disponibile su devACADEMY.it

-->

<?php
	echo "Hello PHP!";
	echo "Iniziamo a studiare!"
?>