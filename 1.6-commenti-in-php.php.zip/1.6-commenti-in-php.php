<!--

	Introduzione a PHP
	Commenti in PHP

	Disponibile su devACADEMY.it

-->

<?php
	/*
		commento su più righe
		riga 2
		riga 3
	*/

	// commento su una sola riga
	echo "Hello PHP!";

	# commento su una sola riga
	echo "Iniziamo a studiare!"
?>